import subprocess
import sys

def run_command(command):
    try:
        subprocess.check_output(command, stderr=subprocess.STDOUT, shell=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Command failed: {e.output.decode()}")
        return False

def check_python_version():
    print(f"Python Version: {sys.version}")

def check_installed_packages():
    try:
        import pkg_resources
        installed_packages = {pkg.key: pkg.version for pkg in pkg_resources.working_set}
        print("Installed Packages and Versions:")
        for package, version in installed_packages.items():
            print(f"{package}: {version}")
    except ImportError:
        print("pkg_resources module is not available. Attempting to fix...")
        if run_command("pip install setuptools"):
            print("Setuptools installed successfully.")
        else:
            print("Failed to install setuptools. Manual installation required.")

def check_cuda_availability():
    try:
        import torch
        if torch.cuda.is_available():
            print(f"CUDA Available: True")
            print(f"CUDA Version: {torch.version.cuda}")
            print(f"cuDNN Version: {torch.backends.cudnn.version()}")
        else:
            print("CUDA is not available. Attempting to reinstall PyTorch with CUDA...")
            fix_pytorch_installation()
    except ImportError:
        print("PyTorch is not installed. Installing PyTorch with CUDA...")
        fix_pytorch_installation()

def fix_pytorch_installation():
    cuda_version = input("Enter your CUDA version (e.g., cu117 for CUDA 11.7): ")
    if run_command(f"pip install torch torchvision torchaudio --extra-index-url https://download.pytorch.org/whl/{cuda_version}"):
        print("PyTorch installed successfully with CUDA support.")
    else:
        print("Failed to install PyTorch with specified CUDA version.")

def check_nvcc_version():
    try:
        nvcc_version = subprocess.check_output(["nvcc", "--version"]).decode()
        print(f"NVCC Version:\n{nvcc_version}")
    except FileNotFoundError:
        print("NVCC is not installed or not in the PATH. Verify CUDA Toolkit installation.")

def check_system_gpu():
    try:
        gpu_info = subprocess.check_output(["nvidia-smi"]).decode()
        print("GPU Details:\n", gpu_info)
    except FileNotFoundError:
        print("nvidia-smi is not available. NVIDIA GPU might not be installed.")

if __name__ == "__main__":
    print("Checking System Environment...\n")
    check_python_version()
    check_installed_packages()
    check_cuda_availability()
    check_nvcc_version()
    check_system_gpu()
