import os
import re
import sys
import shutil
import subprocess
import threading
import unicodedata
import webbrowser
import requests
import pyperclip
import yaml
import pysrt
import torch
from io import BytesIO
from pydub import AudioSegment
from PIL import Image, ImageTk
import tkinter as tk
from tkinter import ttk, filedialog, scrolledtext, messagebox
import yt_dlp as youtube_dl

# ANSI escape sequences for colored and formatted text
class ANSI:
    RESET = '\033[0m'
    BOLD = '\033[1m'
    GREEN = '\033[92m'
    BLUE = '\033[94m'
    RED = '\033[91m'
    YELLOW = '\033[93m'

# Settings (Integrated directly, no external conf.yaml)
settings = {
    "model": "medium.en",
    "language": "en",
    "diarize": False,
    "HF_token": "",
    "one_folder": False
}

AUDIO_EXT = ".wav"
FILE_COUNTER = 0

def sanitize_filename(filename):
    # Remove diacritics and normalize Unicode characters
    normalized = unicodedata.normalize('NFKD', filename)
    sanitized = ''.join(c for c in normalized if not unicodedata.combining(c))
    # Regular Expression to match invalid characters
    invalid_chars_pattern = r'[<>:"/\\|?*]'
    # Replace invalid characters with an underscore
    return re.sub(invalid_chars_pattern, '_', sanitized)

def get_output_filename():
    global FILE_COUNTER
    FILE_COUNTER += 1
    return f"segment_{FILE_COUNTER}{AUDIO_EXT}"

def process_subtitle(audio, sub, output_dir, padding=0.0):
    start_time = max(0, sub.start.ordinal - padding * 1000)
    end_time = min(len(audio), sub.end.ordinal + padding * 1000)
    segment = audio[start_time:end_time]
    output_filename = get_output_filename()
    output_path = os.path.join(output_dir, output_filename)
    segment.export(output_path, format="wav")
    print(f"{ANSI.GREEN}[INFO]{ANSI.RESET} Saved segment to {output_path}")

def diarize_audio_with_srt(audio_file, srt_file, output_dir):
    audio = AudioSegment.from_file(audio_file)
    subs = pysrt.open(srt_file)
    for sub in subs:
        speaker = sub.text.split(']')[0][1:]
        sanitized_speaker = sanitize_filename(speaker)
        speaker_dir = os.path.join(output_dir, sanitized_speaker)
        os.makedirs(speaker_dir, exist_ok=True)
        process_subtitle(audio, sub, speaker_dir)

def extract_audio_with_srt(audio_file, srt_file, output_dir):
    audio = AudioSegment.from_file(audio_file)
    subs = pysrt.open(srt_file)
    os.makedirs(output_dir, exist_ok=True)
    for sub in subs:
        process_subtitle(audio, sub, output_dir)

def merge_segments(output_dir):
    combined_dir = os.path.join(output_dir, "combined_folder")
    os.makedirs(combined_dir, exist_ok=True)

    for folder_name in os.listdir(output_dir):
        folder_path = os.path.join(output_dir, folder_name)
        if not os.path.isdir(folder_path) or folder_name == "combined_folder":
            continue

        for segment_name in os.listdir(folder_path):
            segment_path = os.path.join(folder_path, segment_name)
            new_segment_name = f"{folder_name}_{segment_name.split('_')[-1]}"
            new_segment_path = os.path.join(combined_dir, new_segment_name)
            shutil.move(segment_path, new_segment_path)

        os.rmdir(folder_path)  # Remove the original directory after all its segments have been moved

def find_ffmpeg():
    """Find ffmpeg executable in the system."""
    ffmpeg_path = shutil.which("ffmpeg")
    if ffmpeg_path:
        return os.path.dirname(ffmpeg_path)
    return None

def install_ffmpeg():
    """Install ffmpeg using winget if not found."""
    try:
        print(f"{ANSI.YELLOW}[INFO]{ANSI.RESET} FFmpeg not found. Installing FFmpeg...")
        subprocess.run(["winget", "install", "-e", "--id", "Gyan.FFmpeg"], check=True)
        print(f"{ANSI.GREEN}[INFO]{ANSI.RESET} FFmpeg installation completed.")
    except subprocess.CalledProcessError as e:
        print(f"{ANSI.RED}[ERROR]{ANSI.RESET} Failed to install FFmpeg: {str(e)}")

def clean_up_files(output_directory):
    """Remove .wav files used for splitting, keep original mp3 and srt."""
    for root, dirs, files in os.walk(output_directory):
        for file in files:
            if file.endswith('.wav'):
                os.remove(os.path.join(root, file))

def run_whisperx(audio_files, output_dir, settings):
    # Force CPU mode
    device = 'cpu'
    compute_type = 'int8'
    base_cmd = [
        "whisperx", audio_files, 
        "--device", device,
        "--model", settings["model"], 
        "--output_dir", output_dir, 
        "--language", settings["language"],
        "--output_format", "srt",
        "--compute_type", compute_type
    ]

    if settings["diarize"]:
        base_cmd.extend(["--diarize", "--hf_token", settings["HF_token"]])

    subprocess.run(base_cmd, check=True)

def transcribe_audio(audio_path, output_directory, progress_var, progress_label):
    """Transcribe audio using whisperx and split audio into segments (CPU only)."""
    try:
        # Convert MP3 to WAV if needed
        if not audio_path.lower().endswith('.wav'):
            wav_path = os.path.splitext(audio_path)[0] + ".wav"
            # Convert to wav
            subprocess.run(['ffmpeg', '-i', audio_path, wav_path], check=True)
            audio_path = wav_path

        # Run whisperx transcription
        run_whisperx(audio_path, output_directory, settings)
        srt_file = os.path.join(output_directory, f"{os.path.splitext(os.path.basename(audio_path))[0]}.srt")

        speaker_segments_dir = os.path.join(output_directory, os.path.splitext(os.path.basename(audio_path))[0])
        os.makedirs(speaker_segments_dir, exist_ok=True)

        if settings["diarize"]:
            diarize_audio_with_srt(audio_path, srt_file, speaker_segments_dir)
        else:
            extract_audio_with_srt(audio_path, srt_file, speaker_segments_dir)

        if settings["one_folder"] and not settings["diarize"]:
            merge_segments(output_directory)

        progress_var.set(100)
        progress_label.config(text="100%")
        print(f"{ANSI.GREEN}[INFO]{ANSI.RESET} Transcription completed for: {audio_path}")

        clean_up_files(output_directory)

    except subprocess.CalledProcessError as e:
        print(f"{ANSI.RED}[ERROR]{ANSI.RESET} Transcription failed: {e}")

def download_audio(youtube_url, output_directory, progress_var, progress_label):
    def custom_hook(d):
        if d['status'] == 'finished':
            title_sanitized = sanitize_filename(d['info_dict']['title'])
            new_dir = os.path.join(output_directory, title_sanitized)
            if not os.path.exists(new_dir):
                os.makedirs(new_dir)
            from datetime import datetime
            now_str = datetime.now().strftime("%Y%m%d%H%M%S")
            new_filename = os.path.join(new_dir, f"{title_sanitized}_{now_str}.mp3")
            os.rename(d['filename'], new_filename)
            print(f"{ANSI.GREEN}[INFO]{ANSI.RESET} Downloaded to: {new_filename}")
            progress_var.set(66)
            progress_label.config(text="66%")
            transcribe_audio(new_filename, new_dir, progress_var, progress_label)
        elif d['status'] == 'downloading':
            try:
                progress_str = d['_percent_str'].strip('%')
                progress_float = float(progress_str) * 0.5  # Download represents 50% of progress
                progress_var.set(progress_float)
                progress_label.config(text=f"{int(progress_float)}%")
            except ValueError:
                print(f"{ANSI.RED}[ERROR]{ANSI.RESET} Could not convert progress string to float: {progress_str}")

    ffmpeg_location = find_ffmpeg()

    if not ffmpeg_location:
        install_ffmpeg()
        ffmpeg_location = find_ffmpeg()
        if not ffmpeg_location:
            print(f"{ANSI.RED}[ERROR]{ANSI.RESET} FFmpeg installation failed or not in PATH. Proceeding without FFmpeg.")
            ffmpeg_location = ''

    class MyLogger(object):
        def debug(self, msg):
            pass
        def warning(self, msg):
            if "unable to obtain file audio codec with ffprobe" in msg:
                return
            print(msg)
        def error(self, msg):
            if "unable to obtain file audio codec with ffprobe" in msg:
                return
            print(f"{ANSI.RED}[ERROR]{ANSI.RESET} {msg}")

    ydl_opts = {
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '320',
        }],
        'ffmpeg_location': ffmpeg_location,
        'outtmpl': os.path.join(output_directory, '%(title)s.%(ext)s'),
        'progress_hooks': [custom_hook],
        'quiet': True,
        'no_warnings': True,
        'logger': MyLogger()
    }

    with youtube_dl.YoutubeDL(ydl_opts) as ydl:
        try:
            ydl.download([youtube_url])
        except Exception as e:
            print(f"{ANSI.RED}[ERROR]{ANSI.RESET} Failed to download audio: {e}")

def process_urls(urls, directory, progress_var, progress_label):
    for url in urls:
        if url.strip():
            download_audio(url.strip(), directory, progress_var, progress_label)

def start_process():
    urls = text_area.get("1.0", "end-1c").split('\n')
    directory = filedialog.askdirectory()
    if directory:
        progress_var.set(0)
        progress_label.config(text="0%")
        threading.Thread(target=process_urls, args=(urls, directory, progress_var, progress_label)).start()

def open_website(event):
    webbrowser.open_new("https://www.TemporalLab.com")

def setup_gui():
    window = tk.Tk()
    window.title("Temporal Labs LLC - YouTube MP3 Downloader & Transcription Tool (CPU ONLY)")
    window.geometry("800x600")
    window.config(background='#0A2239')

    # Attempt to load a local logo (optional)
    if os.path.exists('LOGOTEX.PNG'):
        original_logo = Image.open('LOGOTEX.PNG')
        resized_logo = original_logo.resize((200, 200), Image.Resampling.LANCZOS)
        logo = ImageTk.PhotoImage(resized_logo)
    else:
        logo = None

    logo_label = tk.Label(window, image=logo, bg='#0A2239', cursor="hand2")
    if logo:
        logo_label.image = logo
    logo_label.place(relx=0.01, rely=0.95, anchor='sw')
    logo_label.bind("<Button-1>", open_website)

    global text_area
    text_area = scrolledtext.ScrolledText(window, width=70, height=10, font=('Helvetica', 10), wrap=tk.WORD, bg='#0A2239', fg='white')
    text_area.pack(pady=20)

    browse_button = ttk.Button(window, text="Select Output Directory & Start", command=start_process)
    browse_button.pack(pady=10)

    global progress_var, progress_bar, progress_label
    progress_var = tk.DoubleVar()
    progress_bar = ttk.Progressbar(window, variable=progress_var, maximum=100)
    progress_bar.pack(pady=10)

    progress_label = tk.Label(window, text="0%", bg='#0A2239', fg='white')
    progress_label.pack(pady=5)

    crypto_frame = tk.Frame(window, bg='#0A2239')
    crypto_frame.pack(pady=10)

    crypto_label = tk.Label(crypto_frame, text="Crypto Donations:", bg='#0A2239', fg='white')
    crypto_label.grid(row=0, column=0, columnspan=10)

    crypto_addresses = {
        "BTC": "1A1zp1eP5QGefi2DMPTfTL5SLmv7DivfNa",
        "ETH": "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",
        "LTC": "ltc1qwlyjz8aymy9uagqhht5a4kaq06kmv58dxlzyww",
        "SOL": "FVPGxfGT7QWfQEWvXpFkwdgiiKFM3VdvzNG6mEmX8pgi",
        "DOGE": "DAeWAroHCy8nXCoUsobderPRSNXNu1WY34"
    }

    crypto_logos = {
        "BTC": "https://cryptologos.cc/logos/bitcoin-btc-logo.png",
        "ETH": "https://cryptologos.cc/logos/ethereum-eth-logo.png",
        "LTC": "https://cryptologos.cc/logos/litecoin-ltc-logo.png",
        "SOL": "https://cryptologos.cc/logos/solana-sol-logo.png",
        "DOGE": "https://cryptologos.cc/logos/dogecoin-doge-logo.png"
    }

    def copy_to_clipboard(text):
        pyperclip.copy(text)
        messagebox.showinfo("Clipboard", f"Copied to clipboard: {text}")

    def create_crypto_button(crypto, address, logo_url, row):
        response = requests.get(logo_url)
        logo_image = Image.open(BytesIO(response.content)).resize((30, 30), Image.Resampling.LANCZOS)
        logo_photo = ImageTk.PhotoImage(logo_image)
        button = tk.Button(crypto_frame, image=logo_photo, command=lambda: copy_to_clipboard(address), bg='#0A2239', fg='white')
        button.image = logo_photo
        button.grid(row=row, column=0, padx=10)
        label = tk.Label(crypto_frame, text=crypto, bg='#0A2239', fg='white')
        label.grid(row=row, column=1, padx=10)

    for i, (crypto, address) in enumerate(crypto_addresses.items()):
        create_crypto_button(crypto, address, crypto_logos[crypto], i+1)

    window.protocol("WM_DELETE_WINDOW", on_gui_close)
    window.mainloop()

def on_gui_close():
    print(f"{ANSI.GREEN}[INFO]{ANSI.RESET} Closing the application...")
    os._exit(0)

if __name__ == "__main__":
    # Ensure ffmpeg is available
    if not find_ffmpeg():
        install_ffmpeg()
    setup_gui()
    on_gui_close()
